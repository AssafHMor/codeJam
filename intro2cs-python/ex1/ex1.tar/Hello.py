###############################################################################
#FILE: Hello.py
#WRITER: Assaf_Mor + assafm04 + 036539096
#EXCERSICE: intro2cs ex1 2014-2015
#DESCRIPTION:
#a simple program that prints "Hello World!" to the standard output(screen).
###############################################################################
print("Hello World!")